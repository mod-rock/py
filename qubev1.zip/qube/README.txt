1. open app.py
2. open views.py
3. open index.html
4. run app.py
5. go to: http://127.0.0.1:8080/spaceship
6. enter the payload in the textbox
7. click upload